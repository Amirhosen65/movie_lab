window.addEventListener('load', function () {
    var preloader = document.getElementById('pre-loader');
    preloader.style.display = 'none';
});
