<?php
    $proMovies = App\Models\Movie::where('status', true)->where('version', 1)->latest()->paginate(10);
?>

<section class="movie-section section--bg pb-30 section" data-section="latest_series">
    <div class="container text-center">
        <script type="text/javascript">
            atOptions = {
                'key' : '7dd557336a58f6a9f8c8ae558721a819',
                'format' : 'iframe',
                'height' : 90,
                'width' : 728,
                'params' : {}
            };
        </script>
        <script type="text/javascript" src="//headacheaim.com/7dd557336a58f6a9f8c8ae558721a819/invoke.js"></script>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section-header">
                    <h2 class="section-title">Premium Movies</h2>

                </div>
            </div>
        </div>
        <div class="row justify-content-center mb-30-none ">
            <?php $__empty_1 = true; $__currentLoopData = $proMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-xs-4 col-sm-4 col-md-3 col-lg-2 col-xl-2 col-4 mb-30">
                    <div class="movie-item">
                        <div class="movie-thumb mb-3">
                            <img src="<?php echo e(asset($movie->image)); ?>" alt="movie">
                            <?php if($movie->version == 1): ?>
                            <span class="movie-badge">Premium</span>
                            <?php endif; ?>
                            <div class="movie-thumb-overlay">
                                <a class="video-icon" href="<?php echo e(route('movie.details', $movie->slug)); ?>"><i class="fas fa-play"></i></a>
                            </div>
                        </div>
                        <!-- Movie Title -->
                        <a href="<?php echo e(route('movie.details', $movie->slug)); ?>">
                            <h4 class="movie-title two-clamp"><?php echo e($movie->title); ?></h4>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No movies available.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH E:\Web\laravel project\movie_lab\resources\views/frontend/sections/premium.blade.php ENDPATH**/ ?>