<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="page-inner">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Movie Edit</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.movie.update', $movie->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="d-md-flex">
                                        <div class="form-group col-md-4">
                                            <label for="posterImage">Poster Image</label>
                                            <div id="posterPreviewBox" class="mb-2 preview-box">
                                                <span class="watermark" style="<?php echo e($movie->image ? 'display:none;' : ''); ?>">250x100</span>
                                                <img id="posterPreview" src="<?php echo e($movie->image ? asset($movie->image) : ''); ?>"
                                                     alt="Poster Image Preview"
                                                     style="<?php echo e($movie->image ? 'display:block;' : 'display:none;'); ?>">
                                            </div>
                                            <input type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="posterImage">
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group col-md-8">
                                            <label for="bannerImage">Banner Image</label>
                                            <div id="bannerPreviewBox" class="mb-2 preview-box">
                                                <span class="watermark" style="<?php echo e($movie->banner ? 'display:none;' : ''); ?>">250x400</span>
                                                <img id="bannerPreview" src="<?php echo e($movie->banner ? asset($movie->banner) : ''); ?>"
                                                     alt="Banner Image Preview"
                                                     style="<?php echo e($movie->banner ? 'display:block;' : 'display:none;'); ?>">
                                            </div>
                                            <input type="file" name="banner" class="form-control <?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bannerImage">
                                            <?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="email2">Title</label>
                                        <input type="text" name="title" value="<?php echo e($movie->title); ?>" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email2" placeholder="Enter Movie Title">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </div>
                                  <div class="d-md-flex">
                                    <div class="form-group col-md-4">
                                        <label for="categorySelect">Category</label>
                                        <select name="category_id" class="form-select form-control" id="categorySelect">
                                            <option value="">Select Category</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($category->id); ?>" <?php echo e($movie->category_id == $category->id ? 'selected' : ''); ?>>
                                                    <?php echo e($category->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option value="">Not Found</option>
                                            <?php endif; ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="email2">Sub Category</label>
                                        <select name="subcategory_id" class="form-select form-control" id="exampleFormControlSelect1">
                                            <option value="">Select Sub Category</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($subCategory->id); ?>" <?php echo e($movie->subcategory_id == $subCategory->id ? 'selected' : ''); ?>>
                                                    <?php echo e($subCategory->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option value="">Not Found</option>
                                            <?php endif; ?>
                                        </select>
                                      </div>
                                      <div class="form-group col-md-4">
                                        <label for="genres">Genre</label>
                                        <select name="genre" class="form-select form-control" id="exampleFormControlSelect1">
                                            <option value="">Select Genre</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($genre->id); ?>" <?php echo e($movie->genre == $genre->id ? 'selected' : ''); ?>>
                                                    <?php echo e($genre->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option value="">Not Found</option>
                                            <?php endif; ?>

                                        </select>
                                    </div>
                                    </div>
                                  <div class="form-group">
                                    <label for="email2">Meta Description</label>
                                    <textarea name="short_desc" class="form-control <?php $__errorArgs = ['short_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="5"><?php echo e($movie->short_desc); ?></textarea>
                                    <?php $__errorArgs = ['short_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="email2">Description</label>
                                    <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10" id="summernote"><?php echo e($movie->description); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="d-md-flex">
                                    <div class="form-group col-md-6">
                                        <label for="trailerLink">Trailer</label>
                                        <input type="url" value="<?php echo e($movie->trailer); ?>" name="trailer" class="form-control <?php $__errorArgs = ['trailer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="trailerLink" placeholder="YouTube Link">
                                        <?php $__errorArgs = ['trailer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>
                                    <div class="form-group col-md-6">
                                        <label for="email2">Director</label>
                                        <input type="text" value="<?php echo e($movie->director); ?>" name="director" class="form-control <?php $__errorArgs = ['director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email2" placeholder="Enter Director Name">
                                        <?php $__errorArgs = ['director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                  </div>

                                    <div class="d-md-flex">
                                        <div class="form-group col-md-6">
                                            <label for="email2">Casts</label>
                                            <input type="text" name="casts" value="<?php echo e($movie->casts); ?>" class="form-control <?php $__errorArgs = ['casts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email2" placeholder="Ex- Salman Khan, Sharukh Khan">
                                            <?php $__errorArgs = ['casts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="email2">Rating</label>
                                            <input type="text" name="rating"value="<?php echo e($movie->rating); ?>" class="form-control <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email2" placeholder="Enter Movie Rating">
                                            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                  <div class="d-md-flex">

                                    <div class="form-group col-md-6">
                                        <label for="email2">Language</label>
                                        <select name="language" class="form-select form-control" id="exampleFormControlSelect1">
                                            <option value="">Select Language</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($language->id); ?>" <?php echo e($movie->language == $language->id ? 'selected' : ''); ?>>
                                                    <?php echo e($language->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <option value="">Not Found</option>
                                            <?php endif; ?>

                                        </select>
                                    </div>
                                        <div class="form-group col-md-6">
                                            <label for="email2">Version</label>
                                            <select name="version" class="form-select form-control" id="exampleFormControlSelect1">
                                                <option value="0" <?php echo e($movie->version == 0 ? 'selected' : ''); ?>>Free</option>
                                                <option value="1" <?php echo e($movie->version == 1 ? 'selected' : ''); ?>>Premium</option>
                                            </select>
                                        </div>
                                  </div>
                                  <div class="form-group">
                                    <label class="form-label">Tags <a href="#" data-bs-toggle="modal" data-bs-target="#tagCreate">Create New</a></label>
                                    <br>
                                    <div class="selectgroup selectgroup-pills" id="tagListContainer">

                                        <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <label class="selectgroup-item">
                                                <input type="checkbox" name="tags[]" value="<?php echo e($tag->id); ?>" class="selectgroup-input"
                                                <?php $__currentLoopData = $movie->MovieRelationTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($m_tag->id == $tag->id): ?>
                                                checked
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                >
                                                <span class="selectgroup-button"><?php echo e($tag->name); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p>Not Found!</p>
                                        <?php endif; ?>
                                    </div>
                                  </div>

                                    <div class="d-flex">
                                        <div class="form-group">
                                            <label for="statusCheckbox">Status</label>
                                            <br>
                                            <label class="switch" title="Status">
                                                <input type="checkbox" id="statusCheckbox" <?php echo e($movie->status ? 'checked' : ''); ?>>
                                                <span class="slider"></span>
                                            </label>
                                            <input type="hidden" id="statusValue" name="status" value="<?php echo e($movie->status ? '1' : '0'); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="featureCheckbox">Feature</label>
                                            <br>
                                            <label class="switch" title="Feature">
                                                <input type="checkbox" id="featureCheckbox" <?php echo e($movie->feature ? 'checked' : ''); ?>>
                                                <span class="slider"></span>
                                            </label>
                                            <input type="hidden" id="featureValue" name="feature" value="<?php echo e($movie->feature ? '1' : '0'); ?>">
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="">
                                <div class="form-group col-md-5">
                                    <label for="downloadLinks">Download Links</label>
                                    <button type="button" class="btn btn-success btn-xs addDownloadLink fw-bold ms-2">Add New</button>
                                    <div id="downloadLinksContainer" class="pt-2">
                                        
                                    </div>
                                    <?php $__errorArgs = ['download_links'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="text-center pb-10">
                                <button class="btn btn-success">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="tagCreate" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="tagForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Create New Tag</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="name">Tag Name</label>
                                    <input type="text" name="name" id="tagName" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <span class="invalid-feedback" id="tagError" role="alert" style="display: none;">
                                        <strong></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>

<script>
    $(document).ready(function () {
        $('#tagForm').on('submit', function (e) {
            e.preventDefault();

            $.ajax({
                url: "<?php echo e(route('admin.tag.add')); ?>",
                type: "POST",
                data: {
                    _token: <?php echo json_encode(csrf_token(), 15, 512) ?>,
                    name: $('#tagName').val()
                },
                success: function (response) {
                    if (response.success) {
                        $('#tagName').val(''); // Clear the input field
                        $('#tagError').hide(); // Hide error message if any

                        // Trigger Bootstrap Notify alert
                        var content = {};
                        content.message = 'Tag created successfully!';
                        content.title = "Success";
                        content.icon = "fa fa-check";
                        content.url = "#";
                        content.target = "_blank";

                        $.notify(content, {
                            type: 'success',
                            placement: {
                                from: "top",
                                align: "right"
                            },
                            time: 3000,
                            delay: 3000,
                        });

                        // Close the modal
                        $('.modal').modal('hide');

                        // Append the new tag as a checkbox
                        $('#tagListContainer').append(
                            '<label class="selectgroup-item">' +
                                '<input type="checkbox" name="tags[]" value="' + response.tag.id + '" class="selectgroup-input" checked>' +
                                '<span class="selectgroup-button">' + response.tag.name + '</span>' +
                            '</label>'
                        );
                    }
                },
                error: function (xhr) {
                    var errors = xhr.responseJSON.errors;
                    if (errors && errors.name) {
                        $('#tagError').show().find('strong').text(errors.name[0]);
                    }
                }
            });
        });
    });
</script>

<script>
    // Status checkbox event listener
    document.getElementById('statusCheckbox').addEventListener('change', function() {
        document.getElementById('statusValue').value = this.checked ? '1' : '0';
    });

    // Feature checkbox event listener
    document.getElementById('featureCheckbox').addEventListener('change', function() {
        document.getElementById('featureValue').value = this.checked ? '1' : '0';
    });
</script>

<script>
    $(document).ready(function() {
    $('#summernote').summernote();
    });
</script>

<script>
    document.getElementById('posterImage').addEventListener('change', function(event) {
        previewImage(event, 'posterPreview');
    });

    document.getElementById('bannerImage').addEventListener('change', function(event) {
        previewImage(event, 'bannerPreview');
    });

    function previewImage(event, previewElementId) {
        const reader = new FileReader();
        reader.onload = function() {
            const previewElement = document.getElementById(previewElementId);
            previewElement.src = reader.result;
            previewElement.style.display = 'block';
            previewElement.previousElementSibling.style.display = 'none'; // Hide watermark
        }
        reader.readAsDataURL(event.target.files[0]);

        // Ensure the grey box is hidden when an image is selected
        document.getElementById(previewElementId).parentElement.style.backgroundColor = 'transparent';
    }
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const downloadLinksContainer = document.getElementById('downloadLinksContainer');

        // Function to add a new download link input row
        function addDownloadLink() {
            const newLinkRow = document.createElement('div');
            newLinkRow.classList.add('d-flex', 'mb-2', 'download-link-row');

            newLinkRow.innerHTML = `
                <input type="text" name="download_titles[]" class="form-control col-md-5" placeholder="Download Title">
                <input type="url" name="download_links[]" class="form-control col-md-5 mx-2" placeholder="Download Link">
                <button type="button" class="btn btn-danger removeDownloadLink">-</button>
            `;
            downloadLinksContainer.appendChild(newLinkRow);
        }

        // Function to initialize existing download links
        function initializeExistingLinks() {
            const existingLinks = <?php echo json_encode(json_decode($movie->download_links, true), 512) ?>;

            if (Array.isArray(existingLinks) && existingLinks.length > 0) {
                existingLinks.forEach(link => {
                    const linkRow = document.createElement('div');
                    linkRow.classList.add('d-flex', 'mb-2', 'download-link-row');

                    const title = link.title || '';
                    const url = link.link || '';

                    linkRow.innerHTML = `
                        <input type="text" name="download_titles[]" value="${title}" class="form-control col-md-5" placeholder="Download Title">
                        <input type="url" name="download_links[]" value="${url}" class="form-control col-md-5 mx-2" placeholder="Download Link">
                        <button type="button" class="btn btn-danger removeDownloadLink">-</button>
                    `;
                    downloadLinksContainer.appendChild(linkRow);
                });
            } else {
                // Add the initial empty row if no existing links
                addDownloadLink();
            }
        }

        // Initialize existing download links on page load
        initializeExistingLinks();

        // Add a new download link row
        document.querySelector('.addDownloadLink').addEventListener('click', addDownloadLink);

        // Event delegation for removing download link rows
        downloadLinksContainer.addEventListener('click', function (e) {
            if (e.target && e.target.classList.contains('removeDownloadLink')) {
                e.target.closest('.download-link-row').remove();
            }
        });
    });
</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web\laravel project\movie_lab\resources\views/dashboard/movies/edit.blade.php ENDPATH**/ ?>