<?php $__env->startSection('body_content'); ?>

<section class="movie-section section--bg pb-60 pt-80 section" data-section="latest_series">
    <div class="container text-center">
        <script type="text/javascript">
            atOptions = {
                'key' : '7dd557336a58f6a9f8c8ae558721a819',
                'format' : 'iframe',
                'height' : 90,
                'width' : 728,
                'params' : {}
            };
        </script>
        <script type="text/javascript" src="//headacheaim.com/7dd557336a58f6a9f8c8ae558721a819/invoke.js"></script>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section-header">
                    <h2 class="section-title">User Dashboard</h2>
                </div>
            </div>
        </div>
        

        <div class="row">
            <!-- Sidebar Section -->
            <div class="col-md-3">
                <div class="sidebar">
                    <h4>Carla Bird</h4>
                    <p>vibaxuk@mailinator.com</p>
                    <button class="btn">Dashboard</button>
                    <button class="btn">Wishlist</button>
                    <button class="btn">Payment History</button>
                    <button class="btn">Package History</button>
                    <button class="btn">Edit Profile</button>
                    <button class="btn">Logout</button>
                </div>
            </div>

            <!-- Content Section -->
            <div class="col-md-9">
                <!-- My Subscription Card -->
                <div class="card-pattern">
                    <h5 class="section-title">My Subscription</h5>
                    <button class="select-plan-btn mt-3 w-100">SELECT PLAN</button>
                </div>

                <!-- Last Invoice Card -->
                <div class="card-pattern">
                    <h5 class="section-title">Last Invoice</h5>
                    <p>Date:</p>
                    <p>Plan:</p>
                    <p>Amount:</p>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontEndMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web\laravel project\movie_lab\resources\views/frontend/user/dashboard.blade.php ENDPATH**/ ?>