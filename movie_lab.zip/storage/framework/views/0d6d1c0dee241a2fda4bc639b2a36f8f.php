<?php $__env->startPush('style-lib'); ?>
    <link href="<?php echo e(asset('frontend_assets/basic/css/video-js.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('style'); ?>
    
        <style>
            .video-show {
                display: block;
            }

            .video-hide {
                display: none;
            }
        </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('frontend_assets/basic/js/video.min.js')); ?>"></script>
    <!-- Include the YouTube plugin -->
<script src="https://cdn.jsdelivr.net/npm/videojs-youtube@3.0.0/dist/Youtube.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body_content'); ?>

<?php
$downloadLinks = json_decode($movie->download_links, true);
?>

<section class="movie-details-section section--bg ptb-30">
    <div class="container">
        <div class="row mb-20-none">
            <div class="col-xl-8 col-lg-8 mb-20 mt-40">
                <div class="movie-item">
                    <div class="video-show movie-video " id="video_container">
                        <div class="video-show movie-video" id="video_container">
                            <video id="my-video" class="video-js vjs-default-skin" controls preload="auto" height="264"
                                   poster="<?php echo e(asset($movie->banner)); ?>"
                                   data-setup='{ "techOrder": ["youtube"], "sources": [{ "type": "video/youtube", "src": "<?php echo e($movie->trailer); ?>" }], "playbackRates": [0.5, 1, 1.5, 2] }'>
                            </video>
                        </div>
                    </div>

                    <div class="movie-content">
                        <div class="movie-content-inner d-sm-flex justify-content-between align-items-center flex-wrap">
                            <div class="movie-content-left">
                                <h3 class="title"><?php echo e($movie->title); ?></h3>
                                <span class="sub-title">Category : <span class="cat"><?php echo e($movie->RelationCategory->name); ?></span>
                                <?php $__empty_1 = true; $__currentLoopData = $movie->MovieRelationTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a href="#"><?php echo e($tag->name); ?></a>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    Not Fund
                                <?php endif; ?>
                                </span>
                            </div>
                            <div class="movie-content-right d-flex justify-content-between">
                                <div class="movie-widget-area align-items-center">
                                    <span class="movie-widget"><i class="lar la-star text--warning"></i> <?php echo e($movie->rating); ?></span>
                                    <span class="movie-widget"><i class="lar la-eye text--danger"></i> <?php echo e($movie->visitor); ?> views</span>
                                    <span class="movie-widget addWishlist " title="Wishlist"><i class="las la-plus-circle"></i></span>
                                    <span class="movie-widget removeWishlist d-none"><i class="las la-minus-circle"></i></span>
                                </div>

                                

                            </div>
                        </div>
                        <p class="movie-widget__desc"><?php echo e($movie->short_desc); ?></p>

                    </div>
                </div>

                <div class="container mt-10">
                    <script type="text/javascript">
                        atOptions = {
                            'key' : '7dd557336a58f6a9f8c8ae558721a819',
                            'format' : 'iframe',
                            'height' : 90,
                            'width' : 728,
                            'params' : {}
                        };
                    </script>
                    <script type="text/javascript" src="//headacheaim.com/7dd557336a58f6a9f8c8ae558721a819/invoke.js"></script>
                </div>

                <div class="product-tab mt-40">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="product-tab-desc" data-bs-toggle="tab" href="#product-desc-content" role="tab" aria-controls="product-desc-content" aria-selected="true">Description</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="product-tab-team" data-bs-toggle="tab" href="#product-team-content" role="tab" aria-controls="product-team-content" aria-selected="false">Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="product-tab-download" data-bs-toggle="tab" href="#download-content" role="tab" aria-controls="download-content" aria-selected="false">Download Links</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="product-desc-content" role="tabpanel" aria-labelledby="product-tab-desc">
                            <div class="product-desc-content mb-2">
                                <?php echo html_entity_decode($movie->description); ?>

                            </div>

                            <div class="download-buttons">
                                <h3>Download Links</h3>
                                <?php if(!empty($downloadLinks)): ?>
                                    <?php $__currentLoopData = $downloadLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="btn--base btn-download" target="_blank" href="<?php echo e($link['link']); ?>">
                                            <i class="las la-download la-lg"></i> <?php echo e($link['title']); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="product-team-content" role="tabpanel" aria-labelledby="product-tab-team">
                            <div class="product-desc-content">
                                <ul class="team-list">
                                    <li><span>Director:</span> <?php echo e($movie->director); ?></li>
                                    <?php if(!empty($movie->casts)): ?>
                                    <li><span>Cast:</span> <?php echo e($movie->casts); ?></li>
                                    <?php endif; ?>
                                    <li><span>Genres:</span> <?php echo e($movie->RelationGenre->name); ?></li>
                                    <li><span>Language:</span> <?php echo e($movie->RelationLanguage->name); ?></li>
                                </ul>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="download-content" role="tabpanel" aria-labelledby="product-tab-download">
                            <div class="download">
                                <div class="download-buttons mt-3">
                                    <?php if(!empty($downloadLinks)): ?>
                                        <?php $__currentLoopData = $downloadLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="btn--base btn-download" href="<?php echo e($link['link']); ?>">
                                                <i class="las la-download la-lg"></i> <?php echo e($link['title']); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            
            <?php echo $__env->make('frontend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</section>



<?php echo $__env->make('frontend.sections.related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontEndMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web\laravel project\movie_lab\resources\views/frontend/movie_details.blade.php ENDPATH**/ ?>