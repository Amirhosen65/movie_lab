<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css"> <!-- Link to your custom CSS -->
    <style>
        /* styles.css */
body {
    margin: 0;
    padding: 0;
    font-family: 'Arial', sans-serif;
}

.login-background {
    /* background: linear-gradient(45deg, #181461, #0d0b3f); */
    background-image: url(<?php echo e(asset('uploads/default/login.jpg')); ?>);
}

.login-card {
    background-color: #1a1741;
    border-radius: 10px;
    max-width: 400px;
    width: 100%;
}

.login-card h2 {
    font-size: 1.8rem;
    font-weight: 700;
}

.login-card p {
    font-size: 1rem;
    font-weight: 500;
}

.form-control {
    background-color: #1a1741;
    border: 1px solid #4a44f2;
    color: white;
}

.form-control:focus {
    background-color: #1a1741;
    border-color: #715aff;
    box-shadow: none;
    color: white;
}

.form-label {
    font-size: 0.9rem;
}

.form-check-input {
    background-color: #4a44f2;
    border-color: #4a44f2;
}

.form-check-label {
    font-size: 0.9rem;
}

.forgot-password {
    font-size: 0.9rem;
    text-decoration: underline;
}

.btn-primary {
    background-color: #4a44f2;
    border-color: #4a44f2;
}

.btn-primary:hover {
    background-color: #715aff;
    border-color: #715aff;
}

.text-white {
    color: #ffffff !important;
}

    </style>
</head>
<body>
    <div class="container-fluid min-vh-100 d-flex justify-content-center align-items-center login-background">
        <div class="login-card p-4 shadow">
            <h2 class="text-center text-white mb-4">Welcome to PlayLab</h2>
            <p class="text-center text-white mb-4">Admin Login to PlayLab Dashboard</p>
            <form method="POST" action="<?php echo e(route('admin.login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="email" class="form-label text-white">Email*</label>
                    <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label text-white">Password*</label>
                    <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="rememberMe" name="remember_token">
                        <label class="form-check-label text-white" for="rememberMe">Remember Me</label>
                    </div>
                    <a href="#" class="text-white forgot-password">Forgot Password?</a>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-3">LOGIN</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>




<?php /**PATH E:\Web\laravel project\movie_lab\resources\views/dashboard/auth/login.blade.php ENDPATH**/ ?>