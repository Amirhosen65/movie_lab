<?php
    $popularMovie = App\Models\Movie::where('status',true)->orderBy('visitor','desc')->take(5)->get();
?>

<div class="col-md-4">
    <!-- Ads Section -->
    <div class="ads-section text-center mb-4">
        <div class="row">
            <div class="contaner text-center">
                <script type="text/javascript">
                    atOptions = {
                        'key' : 'c14af478439df51c289a9afd377654f2',
                        'format' : 'iframe',
                        'height' : 250,
                        'width' : 300,
                        'params' : {}
                    };
                </script>
                <script type="text/javascript" src="//headacheaim.com/c14af478439df51c289a9afd377654f2/invoke.js"></script>
            </div>
        </div>
    </div>

    <!-- Latest Updates -->
    <h3>Most Popular</h3>

    <?php $__empty_1 = true; $__currentLoopData = $popularMovie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="side-item d-flex align-items-start">
            <a href="<?php echo e(route('movie.details', $movie->slug)); ?>">
                <img src="<?php echo e(asset($movie->image)); ?>" alt="Movie Image">
            </a>
            <div class="ms-3">
                <a class="two-clamp" href="<?php echo e(route('movie.details', $movie->slug)); ?>">
                    <h5><?php echo e($movie->title); ?></h5>
                </a>
                <p ><i class="lar la-star text--warning"></i> <?php echo e($movie->rating); ?> | <?php echo e($movie->release_date); ?></p>
                <p><?php echo e($movie->RelationCategory->name); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div>Not Found</div>
    <?php endif; ?>
        <div class="text-center">
            <script type="text/javascript">
                atOptions = {
                    'key' : 'd20e97997cd23a123b8ab203138d49ab',
                    'format' : 'iframe',
                    'height' : 300,
                    'width' : 160,
                    'params' : {}
                };
            </script>
            <script type="text/javascript" src="//headacheaim.com/d20e97997cd23a123b8ab203138d49ab/invoke.js"></script>
        </div>
</div>
<?php /**PATH E:\Web\laravel project\movie_lab\resources\views/frontend/partials/sidebar.blade.php ENDPATH**/ ?>